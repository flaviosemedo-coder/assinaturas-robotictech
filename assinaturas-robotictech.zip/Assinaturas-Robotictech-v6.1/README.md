# Assinaturas de e-mail da Robotictech

Versão 6.1. Extraia a pasta e abra o arquivo do [Outlook](aplicativo/index.html) ou do [Gmail](suporte/Gmail.html) no navegador.

Consulte o [guia rápido](01-Leia-primeiro.pdf) e as [notas técnicas](02-Guia-tecnico.txt). O [código-fonte](codigo-fonte.zip) contém os arquivos da revisão de entrega no commit `4c193d8f0348a27f984f2182cdd2cd70bd80a8e1`.

Preencha os dados da assinatura, selecione **Copiar assinatura** e cole o resultado nas configurações do e-mail. Confira o [manifesto de integridade](SHA256SUMS.txt) para validar a cópia.
